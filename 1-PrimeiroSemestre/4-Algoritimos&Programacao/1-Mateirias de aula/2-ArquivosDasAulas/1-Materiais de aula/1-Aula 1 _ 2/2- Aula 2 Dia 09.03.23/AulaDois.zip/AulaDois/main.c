/* 
Centro Universitario das Faculdades Metropolitanas Unidas
Aluno: Gabriel Albuquerque de Moura Silva
Curso: Bacharelddo em Ciencia da Computacao
1� Semestre
Data de cria��o: 24/03/2023
*/


#include <stdio.h>
// "locale.h" localiza caracteres para pt-br
#include <locale.h> 
#include <stdlib.h>

	//float n1 = 0, n2 = 0 , soma = 0; //declara vari�vel
	char ge, ap[10], nome[50];
	int id = 0;
	float peso = 0, alt = 0;

int main(int argc, char *argv[]) {
	//limpa a tela para evitar erros de exibicao
	system ("cls");
	 // localiza caracteres para pt-br
	setlocale(LC_ALL,"");
	
	/*
	printf("\n Esse programa recebe dois valores e os soma");
	printf("\n \n Digite o primeiro valor: ");
	//pega uma valor digitado no teclado e coloca na vari�vel "n1"
	scanf("%f",&n1); 
	printf("\nDigite o segundo valor: ");
	//pega uma valor digitado no teclado e coloca na vari�vel "n1"
	scanf("%f",&n2); 
	//vari�vel "soma" recebe o valor da opera��o
	soma = n1 + n2;
	// "%.2f exibe apenas duas casas decimais depois da v�rgula
	printf("\n %.2f + %.2f = %.2f", n1, n2, soma);
	*/
	
	printf("\n ---------------Bem Vindo------------------------");
	printf("\n Digite o seu nome: ");
	// "%[^\n]" para frases
	scanf("%[^\n]",&nome); 

	printf(" Digite o seu apelido: ");
	// "%s" para palavras
	scanf("%s",&ap); 

	printf(" Digite o seu g�nero: ");
	// Espa�o obrigatorio, "%c" para letra
	scanf(" %c",&ge); 

	printf(" Digite a sua idade: ");
	scanf("%d",&id); 
	
	printf(" Digite a sua altura: ");
	scanf("%f",&alt); 

	
	printf(" Digite o seu peso: ");
	scanf("%f",&peso); 

	printf("\n Cadastro realizado");
	printf("\n \n ---------------------------------------");
	
	printf("\n Informa��es cadastradas:");

	printf("\n Nome: %s", nome);
	printf("\n Apelido: %s", ap);
	
	if (ge == 'M'){
			printf("\n Seu g�nero � Masculino: %c", ge);
	} 
	if (ge == 'F'){
			printf("\n Seu g�nero � Feminino: %c", ge);
	}
	
	
	printf("\n Idade: %d anos", id);
	printf("\n Altura: %.2f metros", alt);
	printf("\n Peso: %.2f kilos", peso);

	
	
}
