#include <stdio.h>
#include <stdlib.h>
#include <locale.h> 

int main(int argc, char *argv[]) {
	system ("cls");
	setlocale(LC_ALL,"");
	
	/* Exerc�cio 1
	float base = 0, alt = 0, res = 0;
	printf("Esse programa calcula a �rea de um tri�ngulo \n");
	printf("Insira o valor da base e da altura:");
	scanf("%f%f", &base,  &alt);
	printf("Valor da �rea �: %.2f cm�", (base*alt)/2);	
	*/ 
	
	//Exerc�cio 2
	float sal=0, aum=0, res= 0;
	printf("Esse programa calcula o acr�scimo no sal�rio \n");
	printf("Insira o valor do seu sal�rio:");
	scanf("%f",&sal);
	printf("Digite a porcentagem de aumento (n�o digite %%):");
	scanf("%f",&aum);
	aum = aum/100;

	printf("\nO sal�rio final �: %.2f", sal+(aum*sal));
	
	//no printf %% � usado para exibir % na sa�da
	printf("\n \n-Salario original: %.2f \n-Salario final: %.2f \n-Aumento: %.0f %%", sal, sal+(aum*sal), aum*100);
	return 0;
}
