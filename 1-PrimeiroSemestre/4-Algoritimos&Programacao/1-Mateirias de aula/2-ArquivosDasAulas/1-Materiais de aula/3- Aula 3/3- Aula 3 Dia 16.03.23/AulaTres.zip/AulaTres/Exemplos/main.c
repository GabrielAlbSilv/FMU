#include <stdio.h>
#include <stdlib.h>
#include <locale.h> 

int main(int argc, char *argv[]) {

	float n1 = 0, n2 = 0; //soma = 0, sub = 0, multi = 0, div = 0;
	
	system ("cls");
	setlocale(LC_ALL,"");
	
	
	printf("Esse programa recebe dois n�meros e faz c�lculos com eles \n");
	/*printf("\n Por favor insira o primeiro n�mero:");
	scanf("%f",&n1);
	printf("\n Por favor insira o segundo n�mero:");
	scanf("%f",&n2);
	
	//opera��es aritm�ticas - isoladas
	soma=n1+n2;
	sub=n1-n2;
	multi=n1*n2;
	div=n1/n2;
	printf("\n \n -Soma de %.2f + %.2f = %.2f", n1, n2, soma);
	printf("\n \n -Subtra��o de %.2f - %.2f = %.2f", n1, n2, sub);
	printf("\n \n -Multiplica��o de %.2f x %.2f = %.2f", n1, n2, multi);
	printf("\n \n -Divis�o de %.2f / %.2f = %.2f", n1, n2, div);
	*/
	
	
	//recebendo dois valores no mesmo scanf
	printf("\n Por favor insira os dois n�meros:");
	scanf("%f%f",&n1,&n2);

	//opera��es aritm�ticas - dentro do printf
	printf("\n \n -Soma de %.2f + %.2f = %.2f", n1, n2, n1+n2);
	printf("\n \n -Subtra��o de %.2f - %.2f = %.2f", n1, n2, n1-n2);
	printf("\n \n -Multiplica��o de %.2f x %.2f = %.2f", n1, n2, n1*n2);
	printf("\n \n -Divis�o de %.2f / %.2f = %.2f", n1, n2, n1/n2);
	
	
	return 0;
}
