#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <ctype.h> //Biblioteca para caracteres
#include <locale.h>

int main() {
	system("cls");
	setlocale(LC_ALL,"");
	/*
	float n1, n2;
	char op;
	printf("Calculadora\n");
	scanf("%f %c%f",&n1,&op,&n2);
	switch(op){
		case'+':
			printf("Soma �: %.2f",n1+n2);
			break;
			
		case'-':
			printf("Subrata��o �: %.2f",n1-n2);
			break;
			
		case'*':
			printf("Multiplica��o �: %.2f",n1*n2);
			break;
			
		case'/':
			if(n2 != 0){
				printf("Divis�o: %.2f",n1/n2);
				break;
				
			}else{
				printf("Imposs�vel dividir por zero");
				break;
			}
		break;
		default:
			printf("Erro");
	}
	*/
	/*
	int n;
	printf("\nDigite o n�mero: ");
	scanf("%d",&n);
	switch(n){
		case -10  ... 0:
			printf("\nO n�mero: %D est� entre -10 e 0", n);
			break;
		case 1 ... 11:
			printf("\nO n�mero: %D est� entre 1 e 11", n);
			break;
		
		case 12 ... 24:
			printf("\nO n�mero: %D est� entre 12 e 24", n);
			break;
		
		case 25:
			printf("\n O n�mero: %d � igual a 25",n);
			break;
		
		default:
			printf("\n N�mero fora de todos os intervalos");
	}
	*/
	char letra;
	printf("Digite uma letra: ");
	scanf(" %c",&letra);
	letra = tolower(letra); //deixa a letra min�scula
	if(isalpha(letra)){ //verifica se a letra est� dentro do alfabeto
		switch(letra){
			case 'a':
			case 'e':
			case 'i':
			case 'o':
			case 'u':
				printf("\n A letra: %c � uma vogal",letra);
			break;
			default:
				printf("\nA letra: %c � uma consoante",letra);
		}
	}
	return 0;
}
